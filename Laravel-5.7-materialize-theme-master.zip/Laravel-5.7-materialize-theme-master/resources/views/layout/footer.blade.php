@section('footer')
    <!--   Footer Section -->
    <footer class="page-footer" style="background-color: #607D8B !important;">
        <div class="footer-copyright">
            <div class="container">
                Made by <a class="orange-text text-lighten-3" href="#">Connect You Team | Made in India for Indian
                    People.</a>
            </div>
        </div>
    </footer>
    <!--   Footer Section End  -->
@endsection
@yield('footer')
