@section('css')
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="{{ asset('website/css/materialize.min.css')}}" rel="stylesheet">
    <link href="{{ asset('website/css/style.css')}}" rel="stylesheet">
    <link rel="shortcut icon" href="{{ asset('website/img/favicon.png')}}"/>
@endsection
@yield('css')
