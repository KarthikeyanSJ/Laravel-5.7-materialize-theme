/**
 * Created by vishnu on 25/10/18.
 */
(function($){
    $(function(){

        $('.sidenav').sidenav();

    }); // end of document ready
})(jQuery); // end of jQuery name space